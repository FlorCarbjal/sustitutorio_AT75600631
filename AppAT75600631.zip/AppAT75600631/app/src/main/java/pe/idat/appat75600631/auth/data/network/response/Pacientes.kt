package pe.idat.appat75600631.auth.data.network.response

data class Pacientes(
    val userId: Int,
    val id: Int,
    val title: String,
    val completed: Boolean
)
