package pe.idat.appat75600631.auth.data.network.response

data class Photo(
    val albumId: Int,
    val id: Int,
    val title: String,
    val thumbnailUrl: String
)
