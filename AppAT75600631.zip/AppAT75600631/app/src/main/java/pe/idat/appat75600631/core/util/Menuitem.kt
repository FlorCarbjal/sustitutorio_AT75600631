package pe.idat.appat75600631.core.util

data class Menuitem(
    val titulo: String
)
