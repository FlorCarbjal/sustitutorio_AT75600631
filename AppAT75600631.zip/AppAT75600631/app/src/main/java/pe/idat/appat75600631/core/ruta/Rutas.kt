package pe.idat.appat75600631.core.ruta

sealed class Rutas (val path: String){

}